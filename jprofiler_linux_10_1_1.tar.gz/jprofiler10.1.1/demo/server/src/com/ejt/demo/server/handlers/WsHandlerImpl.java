package com.ejt.demo.server.handlers;

import com.ejt.mock.MockHelper;

import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import java.util.Random;

@WebService(serviceName = "WsHandlerService", portName = "WsHandlerPort")
@SOAPBinding(style = SOAPBinding.Style.RPC)
public class WsHandlerImpl {

    public static final int PORT = Integer.getInteger("wsPort", 10091);
    public static final String NAME = "ws";

    private Random random = new Random(System.nanoTime());

    public double getExchangeRate(String from, String to) {
        return lookupExchangeRate(from);
    }

    private double lookupExchangeRate(String from) {
        int base;
        switch (from) {
            case "USD":
                base = 50000;
                break;
            case "EUR":
                base = 30000;
                break;
            case "GBP":
                base = 20000;
                break;
            default:
                base = 5000;
                break;
        }
        MockHelper.runnable(base + random.nextInt(50000));
        return 1.5;
    }

}
