package com.ejt.demo.server.handlers;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class HandlerHelper {

    private HandlerHelper() {
    }

    public static void makeRmiCall(int rmiRegistryPort) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", rmiRegistryPort);
            RmiHandler rmiHandler = (RmiHandler)registry.lookup(RmiHandler.NAME);
            for (int i = 0; i < 3; i++) {
                rmiHandler.remoteOperation();
            }
        } catch (RemoteException | NotBoundException e) {
            e.printStackTrace();
        }
    }

    private static ThreadLocal<WsHandler> wsHandlerThreadLocal = new ThreadLocal<WsHandler>() {
        @Override
        protected WsHandler initialValue() {
            WsHandlerService handlerService = new WsHandlerService();
            return handlerService.getWsHandlerPort();
        }
    };

    public static void makeWebServiceCall() {
        WsHandler wsHandler = wsHandlerThreadLocal.get();
        for (int i = 0; i < 3; i++) {
            wsHandler.getExchangeRate("USD", "EUR");
        }
        wsHandler.getExchangeRate("EUR", "GBP");
        wsHandler.getExchangeRate("GBP", "JPY");
    }
}
