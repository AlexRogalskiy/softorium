This directory contains the IDE integrations for JProfiler. They should be installed by invoking

Session->IDE integrations from

JProfiler's main menu. This also configures the connection between the JProfiler installation and the IDE plugin.
For more information see the "IDE integrations" chapter in the documentation.